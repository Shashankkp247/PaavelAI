from chatterbot import ChatBot
from chatterbot.trainers import ChatterBotCorpusTrainer

chatbot = ChatBot('Paavel')

def chat(inp):
	res = chatbot.get_response(inp)
	return res