from django.shortcuts import render
from django.shortcuts import redirect

from . import pvl

chats = [{'id':'bot', 'message':"Hi! I'm Paavel!"}]

# Create your views here.


def index(request):
	if request.method == 'GET':
		return render(request, "paavel/index.html", {'chats':chats})
	else:
		usr_chat = request.POST['message']
		chats.append({'id':'usr', 'message':usr_chat})
		print(usr_chat)
		rsp = pvl.chat(usr_chat)
		chats.append({'id':'bot', 'message': rsp })
		return render(request, "paavel/index.html", {'chats':chats})

def clr(request):
	chats.clear()

	return redirect("/")